# utils/binance_api/binance_a.py

from __future__ import annotations

import os
import asyncio
import logging
import uuid
import time
from typing import Dict, Optional, Any, Tuple

from utils.apikey_manager import APIKeyManager, GLOBAL_USER
from utils.context_logger import get_context_logger, ContextAwareLogger
from utils.security_auditor import security_auditor
from utils.performance_monitor import monitor_performance

# ✅ LOGGER
logger = get_context_logger(__name__)

# ✅ Absolute imports
from utils.binance_api.b_config import BinanceConfig
from utils.binance_api.binance_request import BinanceHTTPClient
from utils.binance_api.binance_circuit_breaker import CircuitBreaker
from utils.binance_api.binance_multi_user import UserSessionManager
from utils.binance_api.binance_metrics import AdvancedMetrics
from utils.binance_api.b_map_validator import BMapValidator, MapValidationError
from utils.binance_api.binance_client import DirectBinanceClient

class MapLoader:
    """YAML map dosyalarını yükler ve doğrular."""

    def __init__(self, base_path: str) -> None:
        self.base_path = base_path
        self.maps: Dict[str, Dict[str, Any]] = {}
        self._validator = BMapValidator()

    def load_all(self) -> None:
        """Tüm YAML map dosyalarını yükle."""
        files = ("b_map_public.yaml", "b_map_private.yaml")
        
        for fname in files:
            path = os.path.join(self.base_path, fname)
            
            if not os.path.exists(path):
                logger.warning(f"Map file missing: {path}")
                continue
                
            try:
                data = self._validator.load_yaml(path)
                self._validator.validate(data, fname)
                self.maps[fname.replace(".yaml", "")] = data
                logger.info(f"Loaded map: {fname}")
            except MapValidationError as exc:
                logger.error(f"Map validation failed for {fname}: {exc}")
            except Exception as e:
                logger.error(f"Unexpected error loading {fname}: {e}")

    def get_endpoint(self, name: str) -> Optional[Dict[str, Any]]:
        """Endpoint adını YAML map içinde bul."""
        for map_name, map_data in self.maps.items():
            for section, endpoints in map_data.items():
                if section == "meta":
                    continue
                if name in endpoints:
                    return endpoints[name]
        return None

class BinanceAggregator:
    _instance = None
    _init_lock = asyncio.Lock()

    def __init__(self, base_path: str, config: Optional["BinanceConfig"] = None):
        if hasattr(self, "_initialized") and self._initialized:
            raise RuntimeError("BinanceAggregator singleton already initialized")
        
        # 🔒 Basit kullanıcı lock sistemi
        self._user_locks: Dict[int, asyncio.Lock] = {}
        self._locks_lock = asyncio.Lock()
        
        # 📦 Core initialization
        self.map_loader = MapLoader(base_path)
        self.map_loader.load_all()

        self.config = config or BinanceConfig()
        self.sessions = UserSessionManager(ttl_minutes=60)
        self.circuit_breaker = CircuitBreaker()

        self._cleanup_task: Optional[asyncio.Task] = None
        self._stop_event = asyncio.Event()

        # Global API key
        self.global_api_key = os.getenv("BINANCE_API_KEY")
        self.global_api_secret = os.getenv("BINANCE_API_SECRET")
        self.api_manager = None

        # ✅ Basit rate limiter
        from utils.binance_api.binance_request import UserAwareRateLimiter
        self.rate_limiter = UserAwareRateLimiter()

        self._initialized = True
        logger.info("✅ BinanceAggregator initialized")

    @property
    def metrics_manager(self):
        return AdvancedMetrics.get_instance()

    async def initialize_managers(self):
        """Manager'ları async olarak initialize et"""
        try:
            self.key_manager = await APIKeyManager.get_instance()
            self.api_manager = self.key_manager
            await self.key_manager.ensure_db_initialized()
            logger.info("✅ All managers initialized")
        except Exception as e:
            logger.error(f"❌ Manager initialization failed: {e}")
            raise

    @classmethod
    async def get_instance(cls, base_path: str = None, config: Optional["BinanceConfig"] = None) -> "BinanceAggregator":
        """Async singleton getter"""
        async with cls._init_lock:
            if cls._instance is None:
                if base_path is None:
                    base_path = os.path.abspath(os.path.join(os.path.dirname(__file__)))
                
                cls._instance = cls(base_path, config)
                await cls._instance.initialize_managers()
                    
            return cls._instance

    async def get_user_credentials(self, user_id: Optional[int] = None) -> Tuple[str, str]:
        """Kullanıcı credential'larını al"""
        # 1. Kişisel API
        if user_id and user_id != GLOBAL_USER:
            creds = await self.api_manager.get_apikey(user_id)
            if creds:
                logger.info(f"Using personal API for user {user_id}")
                return creds

        # 2. Global API fallback
        if not self.global_api_key or not self.global_api_secret:
            raise RuntimeError("No Binance API credentials available")

        logger.info("Using global API credentials")
        return self.global_api_key, self.global_api_secret

    def _get_binance_client(self, http_client: "BinanceHTTPClient") -> DirectBinanceClient:
        """Create direct client for YAML-based calls"""
        return DirectBinanceClient(http_client)

    async def _get_or_create_session(self, user_id: int, api_key: str, secret_key: str):
        """Session'ı al veya oluştur"""
        async with self._locks_lock:
            if user_id not in self._user_locks:
                self._user_locks[user_id] = asyncio.Lock()
        
        async with self._user_locks[user_id]:
            session = await self.sessions.get_session(user_id)
            if not session:
                http_client = BinanceHTTPClient(
                    api_key=api_key, 
                    secret_key=secret_key,
                    user_id=user_id
                )
                await self.sessions.add_session(user_id, http_client, self.circuit_breaker)
                session = await self.sessions.get_session(user_id)
            return session

    async def _set_request_context(self, user_id: int, endpoint_name: str):
        """Set context for the current request"""
        ContextAwareLogger.set_user_context(user_id)
        ContextAwareLogger.set_request_context(str(uuid.uuid4())[:8], endpoint_name)

    async def _execute_with_rate_limit(self, user_id: int, endpoint_name: str, operation, estimated_weight: int = 1):
        """Basit rate limit entegrasyonu"""
        if not await self.rate_limiter.acquire(user_id, endpoint_name, estimated_weight):
            from utils.binance_api.binance_exceptions import BinanceRateLimitError
            raise BinanceRateLimitError(f"Rate limit exceeded for user {user_id}")
        
        return await operation()

    # =======================================================
    # 🔹 ANA SORGULAMA METODLARI
    # =======================================================

    async def get_public_data(self, endpoint_name: str, **params) -> Any:
        """Public data sorgusu"""
        return await self._get_data_internal(endpoint_name, None, **params)
        
    async def get_private_data(self, user_id: int, endpoint_name: str, **params) -> Any:
        """Private data sorgusu"""
        return await self._get_data_internal(endpoint_name, user_id, **params)

    async def get_data(self, endpoint_name: str, user_id: Optional[int] = None, **params) -> Any:
        """Akıllı metod - public/private otomatik seçim"""
        if user_id is not None:
            return await self.get_private_data(user_id, endpoint_name, **params)
        else:
            return await self.get_public_data(endpoint_name, **params)

    def _is_public_endpoint(self, endpoint_name: str) -> bool:
        """Endpoint'in public olup olmadığını kontrol et"""
        endpoint_config = self.map_loader.get_endpoint(endpoint_name)
        if not endpoint_config:
            raise ValueError(f"Endpoint not found: {endpoint_name}")
        return not endpoint_config.get('signed', False)


    @monitor_performance("get_data", warning_threshold=2.5)
    async def _get_data_internal(self, endpoint_name: str, user_id: Optional[int], **params) -> Any:
        """Ortak logic - basitleştirilmiş"""
        effective_user_id = user_id if user_id is not None else 0
        
        await self._set_request_context(effective_user_id, endpoint_name)
        
        try:
            # Endpoint kontrolü
            endpoint = self.map_loader.get_endpoint(endpoint_name)
            if not endpoint:
                raise ValueError(f"Endpoint not found: {endpoint_name}")

            # Public endpoint kontrolü
            if user_id is None and not self._is_public_endpoint(endpoint_name):
                raise PermissionError(f"Private endpoint {endpoint_name} requires user authentication")

            # Security audit
            if not await security_auditor.audit_request(user_id, endpoint_name, params):
                raise PermissionError(f"Security audit failed: {endpoint_name}")

            # API credentials
            api_key, secret_key = await self.get_user_credentials(user_id)

            # Session
            session = await self._get_or_create_session(effective_user_id, api_key, secret_key)
            if not session:
                raise RuntimeError("User session creation failed")

            # Rate limit + API call
            async def api_operation():
                return await self._call_direct_endpoint(session.http_client, endpoint, **params)

            result = await self._execute_with_rate_limit(
                user_id=effective_user_id,
                endpoint_name=endpoint_name,
                operation=api_operation,
                estimated_weight=endpoint.get("weight", 1)
            )
            
            return result
                
        except Exception as e:
            logger.error(f"Data request failed: user={effective_user_id}, endpoint={endpoint_name}, error={e}")
            raise
        finally:
            ContextAwareLogger.clear_context()
 
      
 
    async def _call_direct_endpoint(self, http_client: "BinanceHTTPClient", endpoint_config: Dict[str, Any], **params) -> Any:
        """Call endpoint directly using YAML config"""
        binance_client = self._get_binance_client(http_client)
        return await binance_client.call_endpoint(endpoint_config, **params)

    # =======================================================
    # 🔹 TEMİZLİK METODLARI
    # =======================================================
    
    async def start_background_tasks(self, interval: int = 300) -> None:
        """Basit background tasks"""
        if not self._cleanup_task:
            self._cleanup_task = asyncio.create_task(self._cleanup_loop(interval))

    async def stop_background_tasks(self) -> None:
        """Stop background tasks"""
        if self._cleanup_task:
            self._stop_event.set()
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass

    async def _cleanup_loop(self, interval: int) -> None:
        """Basit cleanup loop"""
        while not self._stop_event.is_set():
            try:
                await self.sessions.cleanup_expired_sessions()
                if self.key_manager:
                    await self.key_manager.cleanup_cache()
            except Exception as e:
                logger.error(f"Cleanup error: {e}")
            await asyncio.sleep(interval)
# utils/binance_api/binance_a.py

from __future__ import annotations

import os
import asyncio
import logging
import uuid
import weakref
from typing import Dict, Optional, Any, Tuple

from utils.apikey_manager import APIKeyManager, GLOBAL_USER
from utils.context_logger import get_context_logger, ContextAwareLogger
from utils.security_auditor import security_auditor
from utils.performance_monitor import monitor_performance

# ✅ LOGGER
logger = get_context_logger(__name__)

# ✅ Absolute imports
from utils.binance_api.b_config import BinanceConfig
from utils.binance_api.binance_request import BinanceHTTPClient, UserAwareRateLimiter
from utils.binance_api.binance_multi_user import UserSessionManager
from utils.binance_api.binance_metrics import BinanceMetrics, record_request, record_retry  # ✅ GÜNCELLENDİ
from utils.binance_api.b_map_validator import BMapValidator, MapValidationError
from utils.binance_api.binance_client import DirectBinanceClient

class MapLoader:
    """YAML map dosyalarını yükler ve doğrular."""

    def __init__(self, base_path: str) -> None:
        self.base_path = base_path
        self.maps: Dict[str, Dict[str, Any]] = {}
        self._validator = BMapValidator()

    def load_all(self) -> None:
        """Tüm YAML map dosyalarını yükle."""
        files = ("b_map_public.yaml", "b_map_private.yaml")
        
        for fname in files:
            path = os.path.join(self.base_path, fname)
            
            if not os.path.exists(path):
                logger.warning(f"Map file missing: {path}")
                continue
                
            try:
                data = self._validator.load_yaml(path)
                self._validator.validate(data, fname)
                self.maps[fname.replace(".yaml", "")] = data
                logger.info(f"Loaded map: {fname}")
            except MapValidationError as exc:
                logger.error(f"Map validation failed for {fname}: {exc}")
            except Exception as e:
                logger.error(f"Unexpected error loading {fname}: {e}")

    # utils/binance_api/binance_a.py - MapLoader içinde
    def get_endpoint(self, name: str) -> Optional[Dict[str, Any]]:
        """Yeni YAML formatına uygun endpoint bulma - DEBUG EKLENDİ"""
        for map_name, map_data in self.maps.items():
            for section_name, endpoints in map_data.items():
                if section_name in ["meta", "validation_patterns"]:
                    continue
                if isinstance(endpoints, list):
                    for endpoint in endpoints:
                        if endpoint.get("key") == name:
                            # ✅ DEBUG: Bulunan endpoint detayları
                            # print(f"✅ DEBUG MapLoader found: {name}")
                            # print(f"   Section: {section_name}")
                            # print(f"   Sdk_Method1: {endpoint.get('sdk_method')}")
                            # print(f"   Http_method: {endpoint.get('http_method')}")
                            # print(f"   Path: {endpoint.get('path')}")
                            return endpoint
        
        # print(f"❌ DEBUG MapLoader NOT found: {name}")
        return None
        



class BinanceAggregator:
    _instance = None
    _init_lock = asyncio.Lock()

    def __init__(self, base_path: str, config: Optional["BinanceConfig"] = None):
        if hasattr(self, "_initialized") and self._initialized:
            raise RuntimeError("BinanceAggregator singleton already initialized")
        
        # 🔒 Basit kullanıcı lock sistemi
        self._locks_lock = asyncio.Lock()
        self._user_locks: Dict[int, asyncio.Lock] = {}
        
        # 📦 Core initialization
        self.map_loader = MapLoader(base_path)
        self.map_loader.load_all()

        self.config = config or BinanceConfig()
        self.sessions = UserSessionManager(ttl_minutes=60)

        self._cleanup_task: Optional[asyncio.Task] = None
        self._stop_event = asyncio.Event()

        # Global API key
        self.global_api_key = os.getenv("BINANCE_API_KEY")
        self.global_api_secret = os.getenv("BINANCE_API_SECRET")
        self.api_manager = None

        # ✅ Basit rate limiter
        self.rate_limiter = UserAwareRateLimiter()

        self._initialized = True
        logger.info("✅ BinanceAggregator initialized")

    @property
    def metrics_manager(self):
        return BinanceMetrics.get_instance()

    async def initialize_managers(self):
        """Manager'ları async olarak initialize et"""
        try:
            self.key_manager = await APIKeyManager.get_instance()
            self.api_manager = self.key_manager
            await self.key_manager.ensure_db_initialized()
            logger.info("✅ All managers initialized")
        except Exception as e:
            logger.error(f"❌ Manager initialization failed: {e}")
            raise

    @classmethod
    async def get_instance(cls, base_path: str = None, config: Optional["BinanceConfig"] = None) -> "BinanceAggregator":
        """Async singleton getter"""
        async with cls._init_lock:
            if cls._instance is None:
                if base_path is None:
                    base_path = os.path.abspath(os.path.join(os.path.dirname(__file__)))
                
                cls._instance = cls(base_path, config)
                await cls._instance.initialize_managers()
                    
            return cls._instance

    """ asıl
    async def get_user_credentials(self, user_id: Optional[int] = None) -> Tuple[str, str]:
       
        # 1. Kişisel API (sadece gerçek user ID'ler için)
        if user_id is not None and user_id > 0:  # ✅ DÜZELTİLDİ: user_id > 0 kontrolü
            creds = await self.api_manager.get_apikey(user_id)
            if creds:
                logger.info(f"Using personal API for user {user_id}")
                return creds

        # 2. Global API fallback (user_id=0, None veya diğer durumlar için)
        if not self.global_api_key or not self.global_api_secret:
            raise RuntimeError("No Binance API credentials available")

        logger.info("Using global API credentials")
        return self.global_api_key, self.global_api_secret
        
    """

    # geçiçi
    async def get_user_credentials(self, user_id: Optional[int] = None) -> Tuple[str, str]:
        """Kullanıcı credential'larını al - DEBUG VERSION"""
        print(f"🔍 DEBUG: get_user_credentials called - user_id: {user_id}")  # DEBUG
        
        # 1. Kişisel API (sadece gerçek user ID'ler için)
        if user_id is not None and user_id > 0:
            #print(f"🔍 DEBUG: Trying personal API for user {user_id}")  # DEBUG
            creds = await self.api_manager.get_apikey(user_id)
            if creds:
                logger.info(f"Using personal API for user {user_id}")
                #print(f"🔍 DEBUG: Using personal API credentials")  # DEBUG
                return creds

        # 2. Global API fallback
        #print(f"🔍 DEBUG: Trying global API - global_api_key: {bool(self.global_api_key)}, global_api_secret: {bool(self.global_api_secret)}")  # DEBUG
        if not self.global_api_key or not self.global_api_secret:
            #print(f"🔍 DEBUG: Global API credentials missing!")  # DEBUG
            raise RuntimeError("No Binance API credentials available")

        logger.info("Using global API credentials")
        #print(f"🔍 DEBUG: Using global API credentials")  # DEBUG
        return self.global_api_key, self.global_api_secret
        
         
    async def _get_or_create_session(self, user_id: int, api_key: str, secret_key: str):
        """✅ TAMAMEN DÜZELTİLMİŞ VERSİYON"""
        
        # ✅ Lock oluşturma/güncelleme
        async with self._locks_lock:
            if user_id not in self._user_locks:
                self._user_locks[user_id] = asyncio.Lock()
                print(f"🔒 DEBUG: Lock created for user_id: {user_id}")  # Debug
        
        user_lock = self._user_locks[user_id]
        
        async with user_lock:
            session = await self.sessions.get_session(user_id)
            if not session:
                http_client = BinanceHTTPClient(
                    api_key=api_key, 
                    secret_key=secret_key,
                    user_id=user_id
                )
                await self.sessions.add_session(user_id, http_client)
                session = await self.sessions.get_session(user_id)
            return session
            
     
    #
    async def _set_request_context(self, user_id: int, endpoint_name: str):
        """Set context for the current request"""
        ContextAwareLogger.set_user_context(user_id)
        ContextAwareLogger.set_request_context(str(uuid.uuid4())[:8], endpoint_name)

    async def _execute_with_rate_limit(self, user_id: int, endpoint_name: str, operation, estimated_weight: int = 1):
        """Basit rate limit entegrasyonu"""
        if not await self.rate_limiter.acquire(user_id, endpoint_name, estimated_weight):
            from utils.binance_api.binance_exceptions import BinanceRateLimitError
            raise BinanceRateLimitError(f"Rate limit exceeded for user {user_id}")
        
        return await operation()

    # =======================================================
    # 🔹 METRICS KAYIT FONKSİYONLARI 
    # =======================================================

    async def _record_metrics_success(self, endpoint_name: str, response_time: float, weight_used: int = 1):
        """Başarılı istek için metrics kaydet"""
        try:
            await record_request(  # ✅ GÜNCELLENDİ
                endpoint=endpoint_name,
                response_time=response_time,
                status_code=200,
                weight_used=weight_used
            )
        except Exception as e:
            logger.warning(f"Metrics recording failed: {e}")

    async def _record_metrics_error(self, endpoint_name: str, response_time: float, error: Exception, weight_used: int = 1):
        """Hatalı istek için metrics kaydet"""
        try:
            await record_request(  # ✅ GÜNCELLENDİ
                endpoint=endpoint_name,
                response_time=response_time,
                error=error,
                weight_used=weight_used
            )
        except Exception as e:
            logger.warning(f"Error metrics recording failed: {e}")

    async def _record_retry_metrics(self, endpoint_name: str, attempt: int):
        """Retry için metrics kaydet"""
        try:
            await record_retry(endpoint_name, attempt)  # ✅ GÜNCELLENDİ
        except Exception as e:
            logger.warning(f"Retry metrics recording failed: {e}")

    # =======================================================
    # 🔹 ANA SORGULAMA METODLARI
    # =======================================================

    async def get_public_data(self, endpoint_name: str, **params) -> Any:
        """Public data sorgusu"""
        return await self._get_data_internal(endpoint_name, None, **params)
        
    async def get_private_data(self, user_id: int, endpoint_name: str, **params) -> Any:
        """Private data sorgusu"""
        return await self._get_data_internal(endpoint_name, user_id, **params)

    async def get_data(self, endpoint_name: str, user_id: Optional[int] = None, **params) -> Any:
        """Akıllı metod - public/private otomatik seçim"""
        if user_id is not None:
            return await self.get_private_data(user_id, endpoint_name, **params)
        else:
            return await self.get_public_data(endpoint_name, **params)

    def _is_public_endpoint(self, endpoint_name: str) -> bool:
        """Bölüm adına göre public/private kontrolü"""
        for map_name, map_data in self.map_loader.maps.items():
            for section_name, endpoints in map_data.items():
                if section_name in ["public_spot", "public_futures"]:
                    # Bu bölümdeki tüm endpoint'ler public
                    for endpoint in endpoints:
                        if endpoint.get("key") == endpoint_name:
                            return True
                elif section_name in ["private_spot", "private_futures"]:
                    # Bu bölümdeki tüm endpoint'ler private
                    for endpoint in endpoints:
                        if endpoint.get("key") == endpoint_name:
                            return False
        return False  # Bulunamazsa private kabul et
        
        
        
    @monitor_performance("get_data", warning_threshold=2.5)
    async def _get_data_internal(self, endpoint_name: str, user_id: Optional[int], **params) -> Any:
        """Ortak logic - ORJINAL VERSİYON"""
        effective_user_id = user_id if user_id is not None else 0
        start_time = asyncio.get_event_loop().time()
        
        await self._set_request_context(effective_user_id, endpoint_name)
        
        try:
            # Endpoint kontrolü
            endpoint = self.map_loader.get_endpoint(endpoint_name)
            if not endpoint:
                raise ValueError(f"Endpoint not found: {endpoint_name}")

            # Public endpoint kontrolü
            if user_id is None and not self._is_public_endpoint(endpoint_name):
                raise PermissionError(f"Private endpoint {endpoint_name} requires user authentication")

            # Security audit
            if not await security_auditor.audit_request(user_id, endpoint_name, params):
                raise PermissionError(f"Security audit failed: {endpoint_name}")

            # API credentials
            api_key, secret_key = await self.get_user_credentials(user_id)

            # Session
            session = await self._get_or_create_session(effective_user_id, api_key, secret_key)
            if not session:
                raise RuntimeError("User session creation failed")

            # Rate limit + API call
            async def api_operation():
                return await self._call_direct_endpoint(session.http_client, endpoint, **params)

            result = await self._execute_with_rate_limit(
                user_id=effective_user_id,
                endpoint_name=endpoint_name,
                operation=api_operation,
                estimated_weight=endpoint.get("weight", 1)
            )
            
            # Başarılı metrics kaydı
            response_time = asyncio.get_event_loop().time() - start_time
            await self._record_metrics_success(
                endpoint_name, 
                response_time, 
                endpoint.get("weight", 1)
            )
            
            return result
                
        except Exception as e:
            # Hata metrics kaydı
            response_time = asyncio.get_event_loop().time() - start_time
            await self._record_metrics_error(
                endpoint_name,
                response_time,
                e,
                endpoint.get("weight", 1) if endpoint else 1
            )
            logger.error(f"Data request failed: user={effective_user_id}, endpoint={endpoint_name}, error={e}")
            raise
        finally:
            ContextAwareLogger.clear_context()
            

    def _get_binance_client(self, http_client):
        """Binance client oluştur"""
        return DirectBinanceClient(http_client)
    r"""    
    async def _call_direct_endpoint(self, http_client: "BinanceHTTPClient", endpoint_config: Dict[str, Any], **params) -> Any:
        binance_client = self._get_binance_client(http_client)
        return await binance_client.call_endpoint(endpoint_config, **params)
    """

    # utils/binance_api/binance_a.py - DEBUG EKLENTİSİ
    async def _call_direct_endpoint(self, http_client: "BinanceHTTPClient", endpoint_config: Dict[str, Any], **params) -> Any:
        """Call endpoint directly using YAML config - DEBUG VERSION"""
        # try:
        #     # ✅ DEBUG: Endpoint config detaylı kontrol
        #     endpoint_key = endpoint_config.get('key', 'unknown')
        #     print(f"🔍 DEBUG _call_direct_endpoint: {endpoint_key}")
        #     print(f"   Config keys: {list(endpoint_config.keys())}")
        #     print(f"   Sdk_method: {endpoint_config.get('sdk_method')}")
        #     print(f"   Http_method: {endpoint_config.get('http_method')}")
        #     print(f"   Path: {endpoint_config.get('path')}")
        #     print(f"   Signed: {endpoint_config.get('signed')}")
        #     print(f"   Base: {endpoint_config.get('base')}")
        #     
        binance_client = self._get_binance_client(http_client)
        return await binance_client.call_endpoint(endpoint_config, **params)
        #except Exception as e:
        #    logger.error(f"❌ Direct endpoint call failed: {e}")
        #    raise
            






    # =======================================================
    # 🔹 TEMİZLİK METODLARI
    # =======================================================
    
    async def start_background_tasks(self, interval: int = 300) -> None:
        """Basit background tasks"""
        if not self._cleanup_task:
            self._cleanup_task = asyncio.create_task(self._cleanup_loop(interval))

    async def stop_background_tasks(self) -> None:
        """Stop background tasks"""
        if self._cleanup_task:
            self._stop_event.set()
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass

    async def _cleanup_loop(self, interval: int) -> None:
        """Basit cleanup loop"""
        while not self._stop_event.is_set():
            try:
                await self.sessions.cleanup_expired_sessions()
                if self.key_manager:
                    await self.key_manager.cleanup_cache()
            except Exception as e:
                logger.error(f"Cleanup error: {e}")
            finally:
                ContextAwareLogger.clear_context()
            await asyncio.sleep(interval)


    async def cleanup(self):
        """Tüm kaynakları temizle"""
        await self.stop_background_tasks()
        
        # Session'ları temizle
        if hasattr(self, 'sessions'):
            await self.sessions.cleanup_expired_sessions()
        
        # Lock'ları temizle
        if hasattr(self, '_user_locks'):
            self._user_locks.clear()
        
        logger.info("✅ BinanceAggregator cleanup completed")